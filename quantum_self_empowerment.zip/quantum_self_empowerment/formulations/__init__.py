"""问题建模模块

将各类芯片设计问题转化为QUBO形式。

Modules:
    base: 基类定义
    frequency_allocation: 频率分配问题
    topology_optimization: 拓扑优化问题

Author: [待填写]
Created: 2025-10-16
"""
