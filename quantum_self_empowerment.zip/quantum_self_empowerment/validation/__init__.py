"""验证模块

用于检查解的约束满足情况。

Modules:
    constraint_checker: 约束检查器
    solution_validator: 解验证器

Author: [待填写]
Created: 2025-10-16
"""
